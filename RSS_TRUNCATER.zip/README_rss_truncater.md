# RSS Truncater v1.1
Free to use. Not to redistrubute or sell. If you paid for this, you were scammed.
https://github.com/spyd3rwebs/spyd3rwebs.github.io
spyd3rWebsNews@proton.me

A simple command-line Python script that scans a folder for RSS/XML feed files and trims each one down to a maximum number of items — keeping the most recent entries and removing the rest. Files are edited in place.

---

## Compatibility

| | |
|---|---|
| **OS** | macOS, Windows, Linux |
| **Python** | 3.6 or newer |
| **Feed formats** | RSS 2.0 (`.xml`, `.rss`), Atom (`.xml`) |
| **Encodings** | UTF-8, ISO-8859-1, and any encoding declared in the XML header |

---

## Dependencies

### Required
- **Python 3.6+** — comes pre-installed on macOS and most Linux systems. Windows users can download it from [python.org](https://www.python.org/downloads/).

### Optional (but recommended)
- **lxml** — a faster, more robust XML library that better handles edge cases with namespaces and non-UTF-8 encodings. If lxml is not installed, the script automatically falls back to Python's built-in `xml.etree` module, which works fine for standard feeds.

To install lxml:
```
pip install lxml
```

---

## How to Run

Open a Terminal (macOS/Linux) or Command Prompt (Windows) and run:

```
python rss_truncater.py (or python3 rss_truncater.py) (can run from any directory, does not need to be in folder feeds are located in).
```

On Windows you may need to use `python` instead of `python3`:

```
python rss_truncater.py
```

---

## Step-by-Step Usage

The script will prompt you through three questions:

### Step 1 — Choose a folder

```
Drag a folder into this window (or type the full path) and press Enter:
>
```

You can either **drag and drop** a folder directly from Finder/Explorer into the Terminal window, or **type the full path** manually. Both work. Paths with spaces are handled automatically.

### Step 2 — Choose search depth

```
How deep do you want to go?
  1 = search only the folder you specified
  2 = also search one level of sub-folders
  3 = also search sub-folders of those sub-folders
Enter a number (1 - 3):
>
```

| Depth | What gets searched |
|---|---|
| `1` | Only the folder you specified |
| `2` | That folder + any folders directly inside it |
| `3` | That folder + sub-folders + sub-folders of those sub-folders |

### Step 3 — Choose max items per feed

```
How many max items in each feed?
(Items beyond this number will be removed, keeping the first N items)
>
```

Enter any whole number (e.g. `5`). Every feed found will be trimmed so it contains no more than that many items. Feeds that already have fewer items than your limit are left untouched.

---


## Important Notes

- **Files are modified in place.** The script overwrites each feed file directly — it does not create copies or backups. If you want to preserve originals, make a backup of your folder before running.
- **Items are kept from the top.** The script keeps the first N items as they appear in the file (which in a properly formatted RSS feed are the most recent entries) and removes everything after that.
- **The script is non-destructive if already under the limit.** If a feed has fewer items than your max, it is reported as unchanged and not rewritten.
- **Only `.xml` and `.rss` file extensions are scanned.** Other file types in the folder are ignored entirely.

---

## Troubleshooting

**"Not a valid directory" error on macOS**
This can happen if you type the path manually with backslash-escaped spaces (e.g. `My\ Folder`). Try dragging the folder directly from Finder into the Terminal window instead — this is the most reliable method.

**"Did not complete, Error message: ..."**
The error message printed after this will describe what went wrong. Common causes are a malformed XML file that cannot be parsed, or a file that is locked/read-only. The script will still process all other files it found and only report failures for the ones that had issues.

**lxml not found warning**
The script will still work without lxml using Python's built-in XML parser. If you frequently work with feeds that use non-UTF-8 encodings (like ISO-8859-1), installing lxml is recommended for best results: `pip install lxml`







CHANGE LOG:
V1.1 - added ability to have backslashes in directory designation. Created README.
V1 - Initial build
