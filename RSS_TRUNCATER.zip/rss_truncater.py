#!/usr/bin/env python3
"""
RSS Truncater
Finds RSS/XML feed files in a folder (up to a chosen depth) and
truncates each feed to a maximum number of items.
"""

import os
import sys
import glob


def get_folder_path():
    """Prompt the user to enter or drag-and-drop a folder path."""
    print("\n=== RSS Truncater ===\n")
    print("Drag a folder into this window (or type the full path) and press Enter:")
    raw = input("> ").strip()

    # Strip surrounding quotes that some systems add when dragging folders
    if (raw.startswith('"') and raw.endswith('"')) or \
       (raw.startswith("'") and raw.endswith("'")):
        raw = raw[1:-1]

    # Remove shell escape backslashes (e.g. "My\ Folder" → "My Folder")
    # macOS Terminal inserts these when dragging folders with spaces in the name
    raw = raw.replace("\\ ", " ")

    raw = raw.strip()

    if not os.path.isdir(raw):
        raise ValueError(f"'{raw}' is not a valid directory.")

    return raw


def get_depth():
    """Prompt the user for search depth (1-3)."""
    print("\nHow deep do you want to go?")
    print("  1 = search only the folder you specified")
    print("  2 = also search one level of sub-folders")
    print("  3 = also search sub-folders of those sub-folders")
    print("Enter a number (1 - 3):")
    raw = input("> ").strip()
    if raw not in ("1", "2", "3"):
        raise ValueError(f"'{raw}' is not valid. Please enter 1, 2, or 3.")
    return int(raw)


def get_max_items():
    """Prompt the user for the max number of items to keep per feed."""
    print("\nHow many max items in each feed?")
    print("(Items beyond this number will be removed, keeping the first N items)")
    raw = input("> ").strip()
    if not raw.isdigit() or int(raw) < 1:
        raise ValueError(f"'{raw}' is not valid. Please enter a positive whole number.")
    return int(raw)


def find_feed_files(root_folder, depth):
    """
    Return a list of .xml / .rss file paths found within `root_folder`
    up to `depth` directory levels deep.

    depth=1  → only files directly inside root_folder
    depth=2  → root_folder and its immediate sub-directories
    depth=3  → root_folder, sub-directories, and their sub-directories
    """
    found = []
    root_folder = os.path.abspath(root_folder)

    for dirpath, dirnames, filenames in os.walk(root_folder):
        # Calculate how many levels deep we are relative to root_folder
        rel = os.path.relpath(dirpath, root_folder)
        if rel == ".":
            current_depth = 1
        else:
            current_depth = rel.count(os.sep) + 2  # +2: root is level 1

        if current_depth > depth:
            # Don't descend further — prune sub-directories
            dirnames.clear()
            continue

        for fname in filenames:
            if fname.lower().endswith((".xml", ".rss")):
                found.append(os.path.join(dirpath, fname))

        # Prune dirnames so os.walk won't go deeper than allowed next iteration
        if current_depth >= depth:
            dirnames.clear()

    return found


def truncate_feed(filepath, max_items):
    """
    Parse the RSS/XML file at `filepath` and remove all <item> elements
    beyond the first `max_items`. Writes the result back to the same file.
    Preserves the original encoding and declaration where possible.
    Returns (items_before, items_after).
    """
    # Use lxml if available for better namespace/encoding support,
    # otherwise fall back to stdlib xml.etree.ElementTree.
    try:
        from lxml import etree as ET
        use_lxml = True
    except ImportError:
        import xml.etree.ElementTree as ET
        use_lxml = False

    if use_lxml:
        parser = ET.XMLParser(remove_blank_text=False)
        tree = ET.parse(filepath, parser)
        root = tree.getroot()

        # RSS 2.0: items live inside <channel>
        # Atom: entries are direct children of root — handle both
        channels = root.findall("channel")
        if channels:
            container = channels[0]
            tag_name = "item"
        else:
            container = root
            # Atom feeds use {namespace}entry
            ns = root.tag.split("}")[0].lstrip("{") if "}" in root.tag else ""
            tag_name = f"{{{ns}}}entry" if ns else "entry"

        items = container.findall(tag_name)
        items_before = len(items)

        for item in items[max_items:]:
            container.remove(item)

        items_after = min(items_before, max_items)

        # Detect original encoding from the XML declaration
        with open(filepath, "rb") as f:
            raw_start = f.read(200)
        encoding = "utf-8"
        if b"encoding=" in raw_start.lower():
            import re
            m = re.search(rb'encoding=["\']([^"\']+)["\']', raw_start, re.IGNORECASE)
            if m:
                encoding = m.group(1).decode("ascii")

        tree.write(
            filepath,
            xml_declaration=True,
            encoding=encoding,
            pretty_print=False,
        )

    else:
        # stdlib fallback — does not preserve comments or processing instructions
        import xml.etree.ElementTree as ET

        # Detect encoding first
        with open(filepath, "rb") as f:
            raw_start = f.read(200)
        encoding = "utf-8"
        if b"encoding=" in raw_start.lower():
            import re
            m = re.search(rb'encoding=["\']([^"\']+)["\']', raw_start, re.IGNORECASE)
            if m:
                encoding = m.group(1).decode("ascii")

        tree = ET.parse(filepath)
        root = tree.getroot()

        channels = root.findall("channel")
        if channels:
            container = channels[0]
            tag_name = "item"
        else:
            container = root
            ns = root.tag.split("}")[0].lstrip("{") if "}" in root.tag else ""
            tag_name = f"{{{ns}}}entry" if ns else "entry"

        items = container.findall(tag_name)
        items_before = len(items)

        for item in items[max_items:]:
            container.remove(item)

        items_after = min(items_before, max_items)

        ET.register_namespace("", "")  # avoid ns0 prefixes where possible

        # Write with declaration
        with open(filepath, "wb") as f:
            f.write(f'<?xml version="1.0" encoding="{encoding}"?>'.encode(encoding))
            f.write(ET.tostring(root, encoding=encoding if encoding.lower() != "utf-8" else "unicode").encode(encoding)
                    if encoding.lower() != "utf-8"
                    else ET.tostring(root, encoding="unicode").encode("utf-8"))

    return items_before, items_after


def main():
    try:
        folder = get_folder_path()
        depth = get_depth()
        max_items = get_max_items()

        print(f"\nSearching for RSS/XML files in: {folder}")
        print(f"  Search depth : {depth} level(s)")
        print(f"  Max items    : {max_items}\n")

        feed_files = find_feed_files(folder, depth)

        if not feed_files:
            print("No RSS/XML files found in the specified folder/depth.")
            print("\nI haz success!")
            return

        print(f"Found {len(feed_files)} feed file(s):\n")

        errors = []
        for fp in feed_files:
            rel = os.path.relpath(fp, folder)
            try:
                before, after = truncate_feed(fp, max_items)
                removed = before - after
                status = f"  ✓  {rel}  ({before} items → {after} kept"
                if removed:
                    status += f", {removed} removed"
                status += ")"
                print(status)
            except Exception as e:
                errors.append((rel, str(e)))
                print(f"  ✗  {rel}  ERROR: {e}")

        if errors:
            error_summary = "; ".join(f"{f}: {e}" for f, e in errors)
            print(f"\nDid not complete, Error message: {error_summary}")
        else:
            print("\nI haz success!")

    except KeyboardInterrupt:
        print("\n\nCancelled by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\nDid not complete, Error message: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
